public class Exercise1 {
    public static void main(String[] args) {
        System.out.println("Name: Nguyen Thai Khoi");
        System.out.println("Date of birth: 28/10/2003");
        System.out.println("Student ID: 52100637");
    }
}