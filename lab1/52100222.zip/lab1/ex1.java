public class ex1{
    public static void main(String[] args) {
        System.out.println("Truong Thai Dan Huy - 22/6/2003 - 52100222");
    }
}