interface Vegetable {
    public String getInfor();
}
